"use strict";

module.exports = function() {
  console.log("<%= name %>");
};
