#!/usr/bin/env node

"use strict";

var fn = require("./");
fn();
